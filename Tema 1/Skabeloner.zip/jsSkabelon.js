function init()
{
    // her placeres din JavaScript-kode
    alert("Du trykkede på knappen");
}